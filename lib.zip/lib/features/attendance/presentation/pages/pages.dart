/// Barrel export for attendance pages
library;

export 'confirm_screen.dart';
export 'history_screen.dart';
export 'scan_screen.dart';
