/// Barrel export for attendance data sources
library;

export 'attendance_remote_datasource.dart';
