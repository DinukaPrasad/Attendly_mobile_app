/// Barrel export for settings domain entities
library;

export 'app_settings.dart';
