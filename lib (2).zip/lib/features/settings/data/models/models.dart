/// Barrel export for settings data models
library;

export 'app_settings_model.dart';
